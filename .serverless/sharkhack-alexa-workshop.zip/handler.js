'use strict';

module.exports.hello = (event, context, callback) => {
  const response = {
    version: '1.0',
    response: {
      outputSpeech: {
        type: 'PlainText',
        text: 'Hello SharkHack 2018!',
      },
      shouldEndSession: false,
    }
  };

  callback(null, response);
};
