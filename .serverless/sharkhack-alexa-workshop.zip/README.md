# sharkhack2018 - Step 2
## Update serverless.yml
The main config of the project: serverless.yml

## Add HelloWorld code
Edit handler.js

## Deploy Program
sls deploy
